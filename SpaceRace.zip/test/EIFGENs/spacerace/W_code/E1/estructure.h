#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_11 {union overhead overhead; char data [1];};
struct eif_ex_22 {union overhead overhead; char data [1];};
struct eif_ex_176 {union overhead overhead; char data [8];};
struct eif_ex_179 {union overhead overhead; char data [8];};
struct eif_ex_182 {union overhead overhead; char data [8];};
struct eif_ex_185 {union overhead overhead; char data [8];};
struct eif_ex_188 {union overhead overhead; char data [8];};
struct eif_ex_191 {union overhead overhead; char data [8];};
struct eif_ex_194 {union overhead overhead; char data [8];};
struct eif_ex_197 {union overhead overhead; char data [8];};
struct eif_ex_200 {union overhead overhead; char data [8];};
struct eif_ex_203 {union overhead overhead; char data [8];};
struct eif_ex_206 {union overhead overhead; char data [8];};
struct eif_ex_209 {union overhead overhead; char data [8];};
struct eif_ex_212 {union overhead overhead; char data [8];};
struct eif_ex_215 {union overhead overhead; char data [8];};
struct eif_ex_239 {union overhead overhead; char data [8];};
struct eif_ex_353 {union overhead overhead; char data [8];};
struct eif_ex_557 {union overhead overhead; char data [8];};
struct eif_ex_566 {union overhead overhead; char data [8];};
struct eif_ex_570 {union overhead overhead; char data [8];};
struct eif_ex_605 {union overhead overhead; char data [8];};
struct eif_ex_659 {union overhead overhead; char data [8];};
struct eif_ex_666 {union overhead overhead; char data [8];};
struct eif_ex_673 {union overhead overhead; char data [8];};
struct eif_ex_739 {union overhead overhead; char data [8];};
struct eif_ex_783 {union overhead overhead; char data [8];};
struct eif_ex_808 {union overhead overhead; char data [8];};
struct eif_ex_825 {union overhead overhead; char data [8];};
struct eif_ex_830 {union overhead overhead; char data [8];};
struct eif_ex_835 {union overhead overhead; char data [8];};
struct eif_ex_951 {union overhead overhead; char data [64];};

#ifdef __cplusplus
}
#endif
#endif
